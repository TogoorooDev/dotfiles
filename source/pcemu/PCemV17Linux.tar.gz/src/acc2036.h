void acc2036_init();
