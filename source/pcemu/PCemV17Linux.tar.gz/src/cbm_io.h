void cbm_io_init();
