void i440bx_init();
void i440bx_reset();
