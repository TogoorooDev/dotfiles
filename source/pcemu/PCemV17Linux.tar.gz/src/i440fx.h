void i440fx_init();
void i440fx_reset();
