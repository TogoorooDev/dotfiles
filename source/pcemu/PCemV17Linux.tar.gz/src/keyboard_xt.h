void keyboard_xt_init();
void keyboard_tandy_init();
void keyboard_xt_reset();
void keyboard_xt_poll();
