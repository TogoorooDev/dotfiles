void pc87307_init(uint16_t addr);
