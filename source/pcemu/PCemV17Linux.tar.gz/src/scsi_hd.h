extern scsi_device_t scsi_hd;
