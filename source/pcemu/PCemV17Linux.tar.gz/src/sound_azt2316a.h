extern device_t azt2316a_device;
extern device_t azt1605_device;

void azt2316a_enable_wss(uint8_t enable, void *p);
