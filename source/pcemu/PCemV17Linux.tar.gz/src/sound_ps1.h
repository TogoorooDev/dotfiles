extern device_t ps1_audio_device;
