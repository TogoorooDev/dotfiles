extern device_t pssj_device;
