extern device_t sst_39sf010_device;
