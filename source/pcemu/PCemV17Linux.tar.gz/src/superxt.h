void superxt_init();
