void t3100e_notify_set(uint8_t value);
void t3100e_display_set(uint8_t value);
uint8_t t3100e_display_get();
uint8_t t3100e_config_get();
void t3100e_turbo_set(uint8_t value);
uint8_t t3100e_mono_get();
void t3100e_mono_set(uint8_t value);
