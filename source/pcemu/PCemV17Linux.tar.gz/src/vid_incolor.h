extern device_t incolor_device;
