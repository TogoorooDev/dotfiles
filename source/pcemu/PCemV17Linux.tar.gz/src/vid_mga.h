extern device_t mystique_device;
