extern device_t pc1512_device;
