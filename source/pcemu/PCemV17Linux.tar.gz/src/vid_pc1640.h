extern device_t pc1640_device;
