extern device_t tandy_device;

extern device_t tandy1000_device;
extern device_t tandy1000hx_device;
