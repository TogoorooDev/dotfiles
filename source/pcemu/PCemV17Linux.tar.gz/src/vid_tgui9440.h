extern device_t tgui9400cxi_device;
extern device_t tgui9400cxi_elx_device;
extern device_t tgui9440_device;
