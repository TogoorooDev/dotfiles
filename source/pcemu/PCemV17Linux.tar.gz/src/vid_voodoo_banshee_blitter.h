void voodoo_2d_reg_writel(voodoo_t *voodoo, uint32_t addr, uint32_t val);
