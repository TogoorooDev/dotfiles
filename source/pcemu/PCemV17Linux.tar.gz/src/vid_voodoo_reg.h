void voodoo_reg_writel(uint32_t addr, uint32_t val, void *p);
