void voodoo_triangle_setup(voodoo_t *voodoo);
