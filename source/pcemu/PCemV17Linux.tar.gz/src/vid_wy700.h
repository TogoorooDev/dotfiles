extern device_t wy700_device;
