void vl82c480_init(void);
