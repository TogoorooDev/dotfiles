void w83877f_init(uint16_t base, uint8_t key);
void w83877tf_init(uint16_t base, uint8_t key);
