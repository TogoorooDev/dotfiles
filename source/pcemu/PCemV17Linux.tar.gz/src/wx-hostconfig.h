int hostconfig_open(void *hwnd);
