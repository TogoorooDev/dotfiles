#ifndef SRC_WX_SHADERCONFIG_H_
#define SRC_WX_SHADERCONFIG_H_

#ifdef __cplusplus
extern "C" {
#endif
void shaderconfig_open(void* hwnd, struct glslp_t* glsl);
#ifdef __cplusplus
}
#endif


#endif /* SRC_WX_SHADERCONFIG_H_ */
