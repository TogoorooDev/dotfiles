# zig-xkbcommon

[zig](https://ziglang.org/) bindings for
[xkbcommon](https://xkbcommon.org) that are a little
nicer to use than the output of `zig translate-c`.
